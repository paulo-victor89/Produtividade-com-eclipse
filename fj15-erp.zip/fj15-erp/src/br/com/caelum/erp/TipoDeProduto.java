package br.com.caelum.erp;

public enum TipoDeProduto {
	LIMPEZA, COMIDA, ELETRONICOS, OUTROS;
}
