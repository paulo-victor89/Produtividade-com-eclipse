package br.com.caelum.erp;

public class Contrato {

}
