package br.com.caelum.erp;

public enum FormaDePagamento {
	DINHEIRO, CHEQUE, DEBITO, CREDITO;
}
